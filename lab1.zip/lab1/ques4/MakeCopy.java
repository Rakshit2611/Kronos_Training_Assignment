package com.lab1.ques4;

public class MakeCopy {

	public static int[] copyOf(int[] arr) {

		int n = arr.length;

		int[] copyArr = new int[n];
		for (int i = 0; i < n; i++) {
			copyArr[i] = arr[i];
		}
		return copyArr;
	}

	public static void main(String[] args) {
	
		}

	}

}
