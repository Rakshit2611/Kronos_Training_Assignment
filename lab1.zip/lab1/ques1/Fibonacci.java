package com.lab1.ques1;

public class Fibonacci {
	public static void main(String[] args) {
		double avg = 0;
		System.out.println("First 20 fibonacci numbers are: ");
		int a1 = 1;
		int a2 = 1;
		avg = a1 + a2;
		System.out.print(a1 + " " + a2 + " ");
		for (int i = 0; i < 18; i++) {
			System.out.print((a1 + a2) + " ");
			int t = a2;
			a2 = a1 + a2;
			a1 = t;
			avg += a2;
		}
		System.out.println("");
		avg = avg / 20.0;
		System.out.println("Avg = " + avg);
	}
}
